sysctl -w net.ipv4.ip_forward=1
sysctl -w net.ipv4.conf.all.forwarding=1
sysctl -w net.ipv4.conf.default.rp_filter=0
sysctl -w net.ipv4.conf.all.rp_filter=0
sysctl -w net.ipv4.conf.all.proxy_arp=1

ifconfig ens37 down
ifconfig ens37 172.16.1.1 netmask 255.255.255.0
ifconfig ens37 up

ifconfig ens38 down
ifconfig ens38 172.16.4.1 netmask 255.255.255.0
ifconfig ens38 up

