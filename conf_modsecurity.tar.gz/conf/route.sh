ip rule add fwmark 1 lookup 100
ip route add local 0.0.0.0/0 dev lo table 100

iptables -t mangle -F
#客户端过来的包
iptables -t mangle -A PREROUTING -p tcp  --dest 172.16.4.4 --dport 8080 -j TPROXY  --tproxy-mark 0x1/0x1 --on-port 8080 --on-ip 172.16.4.4 #ngx监听0.0.0.0 OK nax监听172.16.4.4 ok

#OS过来的包
iptables -t mangle -A PREROUTING -p tcp -s 172.16.4.4 --sport 8080 -j MARK --set-xmark 0x1/0xffffffff  #os返回的包
