#!/bin/bash
# CERTIFICATE AUTHORITY
# generate CA private key
openssl genrsa -aes256 -passout pass:password -out rsa_ca_key.pem 4096
# generate CA public key
openssl req -new -x509 -sha256 -passin pass:password -days 365 -subj "/C=CO/ST=State/L=City/O=Organization/CN=AuthorityName" -key rsa_ca_key.pem -out rsa_ca.pem

# FOR EACH SERVER
# generate server private key
openssl genrsa -out rsa_server_key.pem 4096
# generate server certificate
openssl req -new -sha256 -subj "/CN=server_name" -key rsa_server_key.pem -out rsa_server.csr
# generate extension
echo subjectAltName = DNS:server_domain,IP:10.10.10.20,IP:127.0.0.1 > extfile.cnf
# sign the server certificate
openssl x509 -req -sha256 -days 365 -in rsa_server.csr -CA rsa_ca.pem -CAkey rsa_ca_key.pem -CAcreateserial -out rsa_server_cert.pem -extfile extfile.cnf -passin pass:password
# clean up
#rm extfile.cnf rsa_server.csr
