#!/bin/bash
# CERTIFICATE AUTHORITY
# generate CA private key
openssl ecparam -genkey -name secp256k1 -param_enc explicit | openssl ec -aes256 -passout pass:password -out ec_ca_key.pem
# generate CA public key
openssl req -new -x509 -sha256 -passin pass:password -days 365 -subj "/C=CO/ST=State/L=City/O=Organization/CN=AuthorityName" -key ec_ca_key.pem -out ec_ca.pem

# FOR EACH SERVER
# generate server private key
openssl ecparam -name secp256k1 -genkey -param_enc explicit -out ec_server_key.pem
# generate server certificate
openssl req -new -sha256 -subj "/CN=server_name" -key ec_server_key.pem -out ec_server.csr
# generate extension
echo subjectAltName = DNS:server_domain,IP:10.10.10.20,IP:127.0.0.1 > extfile.cnf
# sign the server certificate
openssl x509 -req -sha256 -days 365 -in ec_server.csr -CA ec_ca.pem -CAkey ec_ca_key.pem -CAcreateserial -out ec_server_cert.pem -extfile extfile.cnf -passin pass:password
# clean up
#rm extfile.cnf ec_server.csr
